package com.example.test2;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
